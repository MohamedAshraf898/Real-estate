<?php
/**
 * Template Name: Location
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$GLOBALS['linden_page'] = 'location';
get_header();
?>
<main>
  <section class="hero hero--page">
    <div class="hero__media"><img data-img="city:2200" alt="Tall buildings beside a green park in New Belgrade"></div>
    <div class="wrap hero__content"><span class="eyebrow">Location</span><h1 class="display">At the heart of New Belgrade</h1><p class="lead">The city's business district, green boulevards and the Sava river — all on your doorstep.</p></div>
  </section>

  <section class="section">
    <div class="wrap grid-2" style="align-items:start">
      <div class="map reveal"><iframe title="Map of New Belgrade" loading="lazy" referrerpolicy="no-referrer" src="https://www.openstreetmap.org/export/embed.html?bbox=20.37%2C44.79%2C20.44%2C44.83&amp;layer=mapnik"></iframe></div>
      <div class="stack reveal"><span class="eyebrow">Nearby</span><h2 class="h2">Everything within minutes</h2><p class="lead">Walking and driving times from the main entrance.</p><div class="places" data-places></div></div>
    </div>
  </section>

  <section class="section section--subtle">
    <div class="wrap grid-2">
      <div class="reveal-img" style="aspect-ratio:4/3"><img data-img="city2:1400" alt="Modern tower in New Belgrade" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div>
      <div class="stack reveal"><span class="eyebrow">Neighbourhood</span><h2 class="h2">A district that keeps growing</h2><p class="lead">New Belgrade combines the city's main business hub with wide green boulevards, river walks and a fast-growing food and culture scene. New tram and rail links make the rest of Belgrade minutes away.</p></div>
    </div>
  </section>

  <section class="section section--dark">
    <div class="wrap cta reveal">
      <div class="stack"><h2 class="h2">Come and see the location</h2><p class="lead">Our team will walk you around the neighbourhood after your viewing.</p></div>
      <a class="btn btn--primary" href="<?php echo esc_url( linden_link( 'contact' ) ); ?>">Book a viewing</a>
    </div>
  </section>
</main>
<?php get_footer();
