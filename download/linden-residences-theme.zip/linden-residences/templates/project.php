<?php
/**
 * Template Name: The Project
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$GLOBALS['linden_page'] = 'project';
get_header();
?>
<main>
  <section class="hero hero--page">
    <div class="hero__media"><img data-img="facade:2200" alt="Building facade with balconies and greenery"></div>
    <div class="wrap hero__content"><span class="eyebrow">The project</span><h1 class="display">Architecture that breathes</h1><p class="lead">Three wings, planted terraces and a facade that filters light like leaves.</p></div>
  </section>

  <section class="section">
    <div class="wrap grid-2">
      <div class="stack reveal">
        <span class="eyebrow">Design</span><h2 class="h2">A facade inspired by the linden tree</h2>
        <p class="lead">Slender vertical fins and deep balconies give shade in summer and let low winter sun in. Natural stone, oak and bronze-toned metal age beautifully over time.</p>
        <a class="btn btn--outline" href="#" style="justify-self:start" onclick="return false">Download brochure (PDF)</a>
      </div>
      <div class="reveal-img" style="aspect-ratio:4/5"><img data-img="tower:1400" alt="Close-up of the building facade" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div>
    </div>
  </section>

  <section class="section section--subtle">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">At a glance</span><h2 class="h2">The building in numbers</h2></div>
      <div class="keyfacts reveal">
        <div class="keyfact"><i data-icon="floor"></i><div><b>3 wings</b><small>A · B · V</small></div></div>
        <div class="keyfact"><i data-icon="floor"></i><div><b>14 floors</b><small>Highest point 52 m</small></div></div>
        <div class="keyfact"><i data-icon="bed"></i><div><b>96 homes</b><small>Studio to penthouse</small></div></div>
        <div class="keyfact"><i data-icon="briefcase"></i><div><b>14 units</b><small>Retail &amp; offices</small></div></div>
        <div class="keyfact"><i data-icon="tree"></i><div><b>3,200 m²</b><small>Gardens &amp; rooftop parks</small></div></div>
        <div class="keyfact"><i data-icon="parking"></i><div><b>240 spaces</b><small>With EV charging</small></div></div>
      </div>
    </div>
  </section>

  <section class="section section--dark" id="amenities">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Amenities</span><h2 class="h2">Shared spaces, private comfort</h2></div>
      <div class="tabs" role="tablist" aria-label="Amenities">
        <button role="tab" id="pt1" aria-controls="pa1" aria-selected="true">Rooftop parks</button>
        <button role="tab" id="pt2" aria-controls="pa2" aria-selected="false" tabindex="-1">Fitness</button>
        <button role="tab" id="pt3" aria-controls="pa3" aria-selected="false" tabindex="-1">Restaurant</button>
      </div>
      <div class="panel grid-2" id="pa1" role="tabpanel" aria-labelledby="pt1"><div class="panel__img"><img data-img="rooftop2:1400" alt="Rooftop terrace with lounge seating" loading="lazy"></div><div class="stack"><h3 class="h3">Gardens in the sky</h3><p class="lead">Lawns, lounge terraces and outdoor kitchens on two rooftops.</p></div></div>
      <div class="panel grid-2" id="pa2" role="tabpanel" aria-labelledby="pt2" hidden><div class="panel__img"><img data-img="gym:1400" alt="Gym with city view" loading="lazy"></div><div class="stack"><h3 class="h3">Two private gyms</h3><p class="lead">Open 24/7 for residents, with a yoga and stretching studio.</p></div></div>
      <div class="panel grid-2" id="pa3" role="tabpanel" aria-labelledby="pt3" hidden><div class="panel__img"><img data-img="restaurant:1400" alt="Terrace restaurant" loading="lazy"></div><div class="stack"><h3 class="h3">Top-floor café &amp; restaurant</h3><p class="lead">Breakfast to late dinner with views across the river.</p></div></div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Gallery</span><h2 class="h2">Renders &amp; interiors</h2></div>
      <div class="masonry">
        <figure class="reveal"><img data-img="block:900" alt="Exterior of the residential wing" loading="lazy"></figure>
        <figure class="reveal"><img data-img="living1:900" alt="Living room" loading="lazy"></figure>
        <figure class="reveal"><img data-img="kitchen1:900" alt="Kitchen with island" loading="lazy"></figure>
        <figure class="reveal"><img data-img="bed1:900" alt="Bedroom" loading="lazy"></figure>
        <figure class="reveal"><img data-img="rooftop:900" alt="Rooftop park" loading="lazy"></figure>
        <figure class="reveal"><img data-img="living3:900" alt="Lounge by the window" loading="lazy"></figure>
      </div>
    </div>
  </section>

  <section class="section section--subtle" id="progress">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Progress</span><h2 class="h2">Construction progress</h2><p class="lead">Updated every month with photos and drone footage.</p></div>
      <div class="timeline reveal">
        <div class="tl done"><i data-icon="check"></i><div><b>Building permit</b><small>Q1 2025</small></div></div>
        <div class="tl done"><i data-icon="check"></i><div><b>Foundations</b><small>Q3 2025</small></div></div>
        <div class="tl now"><i data-icon="cube"></i><div><b>Structure</b><small>In progress · Q2 2026</small></div></div>
        <div class="tl"><i data-icon="clock"></i><div><b>Facade &amp; interiors</b><small>Q1 2027</small></div></div>
        <div class="tl"><i data-icon="clock"></i><div><b>Handover</b><small>Q3 2027</small></div></div>
      </div>
    </div>
  </section>

  <section class="section section--dark">
    <div class="wrap cta reveal">
      <div class="stack"><h2 class="h2">Visit the sales gallery</h2><p class="lead">See materials, finishes and the show apartment in person.</p></div>
      <a class="btn btn--primary" href="<?php echo esc_url( linden_link( 'contact' ) ); ?>">Book a visit</a>
    </div>
  </section>
</main>
<?php get_footer();
